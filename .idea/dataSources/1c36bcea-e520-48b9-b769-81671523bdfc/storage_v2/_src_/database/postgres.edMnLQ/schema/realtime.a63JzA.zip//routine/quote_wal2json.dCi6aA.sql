create function quote_wal2json(entity regclass) returns text
    immutable
    strict
    language sql
as
$$
  SELECT
    realtime.wal2json_escape_identifier(nsp.nspname::text)
    || '.'
    || realtime.wal2json_escape_identifier(pc.relname::text)
  FROM pg_class pc
  JOIN pg_namespace nsp ON pc.relnamespace = nsp.oid
  WHERE pc.oid = entity
$$;

alter function quote_wal2json(unknown) owner to supabase_realtime_admin;

grant execute on function quote_wal2json(unknown) to postgres;

grant execute on function quote_wal2json(unknown) to anon;

grant execute on function quote_wal2json(unknown) to authenticated;

grant execute on function quote_wal2json(unknown) to service_role;

grant execute on function quote_wal2json(unknown) to dashboard_user;

