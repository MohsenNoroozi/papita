create function send_binary(payload bytea, event text, topic text, private boolean DEFAULT true) returns void
    language plpgsql
as
$$
DECLARE
  generated_id uuid;
BEGIN
  BEGIN
    generated_id := gen_random_uuid();

    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    INSERT INTO realtime.messages (id, binary_payload, event, topic, private, extension)
    VALUES (generated_id, payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      RAISE WARNING 'WarnSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;

alter function send_binary(unknown, unknown, unknown, unknown) owner to supabase_realtime_admin;

grant execute on function send_binary(unknown, unknown, unknown, unknown) to postgres;

grant execute on function send_binary(unknown, unknown, unknown, unknown) to dashboard_user;

