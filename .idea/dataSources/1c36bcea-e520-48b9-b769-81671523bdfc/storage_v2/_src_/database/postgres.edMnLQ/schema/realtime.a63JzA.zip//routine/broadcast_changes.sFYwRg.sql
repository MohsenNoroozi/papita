create function broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text DEFAULT 'ROW'::text) returns void
    language plpgsql
as
$$
DECLARE
    -- Declare a variable to hold the JSONB representation of the row
    row_data jsonb := '{}'::jsonb;
BEGIN
    IF level = 'STATEMENT' THEN
        RAISE EXCEPTION 'function can only be triggered for each row, not for each statement';
    END IF;
    -- Check the operation type and handle accordingly
    IF operation = 'INSERT' OR operation = 'UPDATE' OR operation = 'DELETE' THEN
        row_data := jsonb_build_object('old_record', OLD, 'record', NEW, 'operation', operation, 'table', table_name, 'schema', table_schema);
        PERFORM realtime.send (row_data, event_name, topic_name);
    ELSE
        RAISE EXCEPTION 'Unexpected operation type: %', operation;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Failed to process the row: %', SQLERRM;
END;

$$;

alter function broadcast_changes(unknown, unknown, unknown, unknown, unknown, unknown, unknown, unknown) owner to supabase_realtime_admin;

grant execute on function broadcast_changes(unknown, unknown, unknown, unknown, unknown, unknown, unknown, unknown) to postgres;

grant execute on function broadcast_changes(unknown, unknown, unknown, unknown, unknown, unknown, unknown, unknown) to dashboard_user;

