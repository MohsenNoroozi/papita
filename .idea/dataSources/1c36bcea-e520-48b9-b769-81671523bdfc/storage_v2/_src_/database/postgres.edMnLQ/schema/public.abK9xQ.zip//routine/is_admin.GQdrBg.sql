create function is_admin() returns boolean
    stable
    language sql
as
$$
select coalesce(auth.jwt() -> 'app_metadata' ->> 'role', '') = 'admin'
$$;

alter function is_admin() owner to postgres;

grant execute on function is_admin() to anon;

grant execute on function is_admin() to authenticated;

grant execute on function is_admin() to service_role;

