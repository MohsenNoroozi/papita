create function check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) returns boolean
    immutable
    language plpgsql
as
$$
/*
Casts *val_1* and *val_2* as type *type_* and check the *op* condition for truthiness
*/
declare
    op_symbol text = (
        case
            when op = 'eq' then '='
            when op = 'neq' then '!='
            when op = 'lt' then '<'
            when op = 'lte' then '<='
            when op = 'gt' then '>'
            when op = 'gte' then '>='
            when op = 'in' then '= any'
            else 'UNKNOWN OP'
        end
    );
    res boolean;
begin
    execute format(
        'select %L::'|| type_::text || ' ' || op_symbol
        || ' ( %L::'
        || (
            case
                when op = 'in' then type_::text || '[]'
                else type_::text end
        )
        || ')', val_1, val_2) into res;
    return res;
end;
$$;

alter function check_equality_op(unknown, unknown, unknown, unknown) owner to supabase_realtime_admin;

grant execute on function check_equality_op(unknown, unknown, unknown, unknown) to postgres;

grant execute on function check_equality_op(unknown, unknown, unknown, unknown) to anon;

grant execute on function check_equality_op(unknown, unknown, unknown, unknown) to authenticated;

grant execute on function check_equality_op(unknown, unknown, unknown, unknown) to service_role;

grant execute on function check_equality_op(unknown, unknown, unknown, unknown) to dashboard_user;

