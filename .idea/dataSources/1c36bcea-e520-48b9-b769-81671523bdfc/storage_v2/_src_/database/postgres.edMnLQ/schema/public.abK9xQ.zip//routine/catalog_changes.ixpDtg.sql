create function catalog_changes(since timestamp with time zone) returns jsonb
    stable
    language sql
as
$$
select jsonb_build_object(
               'sources', coalesce((select jsonb_agg(jsonb_build_object(
                'id', id, 'title', title, 'collectionId', collection_id, 'position', position,
                'updatedAt', updated_at,
                'deletedAt', case when deleted then updated_at end))
                                    from sources where updated_at > since), '[]'::jsonb),
               'words', coalesce((select jsonb_agg(jsonb_build_object(
                'id', id, 'en', en, 'sense', sense, 'fa', fa, 'level', level,
                'updatedAt', updated_at,
                'deletedAt', case when deleted then updated_at end))
                                  from words where updated_at > since), '[]'::jsonb),
               'sourceWords', coalesce((select jsonb_agg(jsonb_build_object(
                'sourceId', source_id, 'wordId', word_id, 'position', position,
                'example', example, 'exampleFa', example_fa,
                'updatedAt', updated_at,
                'deletedAt', case when deleted then updated_at end))
                                        from source_words where updated_at > since), '[]'::jsonb),
           -- ۵ ثانیه همپوشانی تا تراکنش‌های دیر commit‌شده از دست نروند (merge در اپ idempotent است)
               'nextSince', now() - interval '5 seconds'
       );
$$;

alter function catalog_changes(timestamp with time zone) owner to postgres;

grant execute on function catalog_changes(timestamp with time zone) to authenticated;

grant execute on function catalog_changes(timestamp with time zone) to service_role;

