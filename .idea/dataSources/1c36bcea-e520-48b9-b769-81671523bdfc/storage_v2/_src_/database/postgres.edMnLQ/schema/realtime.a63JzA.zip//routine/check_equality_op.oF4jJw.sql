create function check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text, negate boolean) returns boolean
    stable
    language plpgsql
as
$$
declare
    op_symbol text;
    res boolean;
begin
    -- IS DISTINCT FROM / IS NOT DISTINCT FROM: infix, both sides typed literals
    if op = 'isdistinct' then
        execute format(
            'select %L::%s %s %L::%s',
            val_1,
            type_::text,
            case when negate then 'IS NOT DISTINCT FROM' else 'IS DISTINCT FROM' end,
            val_2,
            type_::text
        ) into res;
        return res;
    end if;

    -- IS requires a keyword RHS (NULL, TRUE, FALSE, UNKNOWN), not a typed literal
    if op = 'is' then
        if val_2 not in ('null', 'true', 'false', 'unknown') then
            raise exception 'invalid value for is filter: must be null, true, false, or unknown';
        end if;
        execute format(
            'select %L::%s %s %s',
            val_1,
            type_::text,
            case when negate then 'IS NOT' else 'IS' end,
            upper(val_2)
        ) into res;
        return res;
    end if;

    op_symbol = case
        when op = 'eq'    then '='
        when op = 'neq'   then '!='
        when op = 'lt'    then '<'
        when op = 'lte'   then '<='
        when op = 'gt'    then '>'
        when op = 'gte'   then '>='
        when op = 'in'    then '= any'
        when op = 'like'   then 'LIKE'
        when op = 'ilike'  then 'ILIKE'
        when op = 'match'  then '~'
        when op = 'imatch' then '~*'
        else null
    end;

    if op_symbol is null then
        raise exception 'unsupported equality operator: %', op::text;
    end if;

    execute format(
        'select %L::%s %s (%L::%s)',
        val_1,
        type_::text,
        op_symbol,
        val_2,
        case when op = 'in' then type_::text || '[]' else type_::text end
    ) into res;

    return case when negate then not res else res end;
end;
$$;

alter function check_equality_op(unknown, unknown, unknown, unknown, unknown) owner to supabase_realtime_admin;

grant execute on function check_equality_op(unknown, unknown, unknown, unknown, unknown) to postgres;

grant execute on function check_equality_op(unknown, unknown, unknown, unknown, unknown) to anon;

grant execute on function check_equality_op(unknown, unknown, unknown, unknown, unknown) to authenticated;

grant execute on function check_equality_op(unknown, unknown, unknown, unknown, unknown) to service_role;

grant execute on function check_equality_op(unknown, unknown, unknown, unknown, unknown) to dashboard_user;

