create function to_regrole(role_name text) returns regrole
    immutable
    language sql
as
$$ select role_name::regrole $$;

alter function to_regrole(unknown) owner to supabase_realtime_admin;

grant execute on function to_regrole(unknown) to postgres;

grant execute on function to_regrole(unknown) to anon;

grant execute on function to_regrole(unknown) to authenticated;

grant execute on function to_regrole(unknown) to service_role;

grant execute on function to_regrole(unknown) to dashboard_user;

