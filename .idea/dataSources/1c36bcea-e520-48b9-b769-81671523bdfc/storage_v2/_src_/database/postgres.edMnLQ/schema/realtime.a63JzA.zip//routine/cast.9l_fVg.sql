create function "cast"(val text, type_ regtype) returns jsonb
    immutable
    language plpgsql
as
$$
declare
  res jsonb;
begin
  if type_::text = 'bytea' then
    return to_jsonb(val);
  end if;
  execute format('select to_jsonb(%L::'|| type_::text || ')', val) into res;
  return res;
end
$$;

alter function "cast"(unknown, unknown) owner to supabase_realtime_admin;

grant execute on function "cast"(unknown, unknown) to postgres;

grant execute on function "cast"(unknown, unknown) to anon;

grant execute on function "cast"(unknown, unknown) to authenticated;

grant execute on function "cast"(unknown, unknown) to service_role;

grant execute on function "cast"(unknown, unknown) to dashboard_user;

