create function wake_lifecycle_state() returns trigger
    security definer
    SET search_path = pg_catalog
    language plpgsql
as
$$
BEGIN
    IF TG_OP = 'INSERT' AND NEW.lifecycle_configuration IS NULL THEN
        RETURN NEW;
    END IF;

    PERFORM storage.reconcile_lifecycle_state(NEW.id, false);
    RETURN NEW;
END;
$$;

alter function wake_lifecycle_state() owner to supabase_storage_admin;

