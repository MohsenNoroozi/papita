create function filters_hash(filters realtime.user_defined_filter[]) returns bytea
    immutable
    strict
    parallel safe
    language sql
as
$$
  select pg_catalog.int8send(pg_catalog.hash_array_extended(filters, 0))
      || pg_catalog.int8send(pg_catalog.hash_array_extended(filters, 1))
$$;

alter function filters_hash(unknown) owner to supabase_realtime_admin;

grant execute on function filters_hash(unknown) to postgres;

grant execute on function filters_hash(unknown) to anon;

grant execute on function filters_hash(unknown) to authenticated;

grant execute on function filters_hash(unknown) to service_role;

grant execute on function filters_hash(unknown) to dashboard_user;

