create function sync_progress(changes jsonb, since timestamp with time zone) returns jsonb
    language plpgsql
as
$$
begin
    insert into user_progress (user_id, word_id, box, due, u, deleted)
    select auth.uid(),
           (c->>'wordId')::bigint,
           (c->>'box')::smallint,
           case when c->>'due' is null then null
                else to_timestamp((c->>'due')::bigint / 1000.0) end,
           (c->>'u')::bigint,
           coalesce((c->>'deleted')::boolean, false)
    from jsonb_array_elements(changes) c
    on conflict (user_id, word_id) do update
        set box = excluded.box,
            due = excluded.due,
            u = excluded.u,
            deleted = excluded.deleted
    where excluded.u > user_progress.u;

    return jsonb_build_object(
            'changes', coalesce((select jsonb_agg(jsonb_build_object(
                    'wordId', word_id, 'box', box,
                    'due', (extract(epoch from due) * 1000)::bigint,
                    'u', u, 'deleted', deleted))
                                 from user_progress
                                 where user_id = auth.uid() and updated_at > since), '[]'::jsonb),
            'nextSince', now() - interval '5 seconds'
           );
end $$;

alter function sync_progress(jsonb, timestamp with time zone) owner to postgres;

grant execute on function sync_progress(jsonb, timestamp with time zone) to authenticated;

grant execute on function sync_progress(jsonb, timestamp with time zone) to service_role;

